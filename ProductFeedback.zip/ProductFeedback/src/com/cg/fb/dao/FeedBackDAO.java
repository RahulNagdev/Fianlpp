package com.cg.fb.dao;

import com.cg.fb.dto.Feedback;

public interface FeedBackDAO {
public void addFeedback(Feedback fb);
}
