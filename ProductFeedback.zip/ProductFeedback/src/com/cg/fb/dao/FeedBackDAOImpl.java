package com.cg.fb.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.fb.dto.Feedback;
@Repository("feedbackdao")

public class FeedBackDAOImpl implements FeedBackDAO {
	@PersistenceContext
	EntityManager em;

public void addFeedback(Feedback fb){
	em.persist(fb);	
	em.flush();

}
}
