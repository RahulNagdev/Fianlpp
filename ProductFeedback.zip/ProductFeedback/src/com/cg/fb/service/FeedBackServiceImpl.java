package com.cg.fb.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fb.dao.FeedBackDAO;
import com.cg.fb.dto.Feedback;

@Service("feedbackservice")
@Transactional

public class FeedBackServiceImpl implements FeedBackService{
	@Autowired
	FeedBackDAO feedbackdao;

	@Override
	public void addFeedback(Feedback fb) {
		// TODO Auto-generated method stub
		feedbackdao.addFeedback(fb);
		
	}

}
