package com.cg.fb.service;

import com.cg.fb.dto.Feedback;

public interface FeedBackService {
	public void addFeedback(Feedback fb);
}