package com.cg.fb.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="Feedback")
public class Feedback {
	
	@Column(name="Order_id")
	private int OrderId;
	
	@Column(name="Product_id")
	private int ProductId;
	
	@Column(name="User_id")
	private int UserId;
	
	@Column(name="Reviews")
	private String UserReview;
	
	@Column(name="Rating")
	private float UserRating;

	public int getOrderId() {
		return OrderId;
	}

	public void setOrderId(int orderId) {
		OrderId = orderId;
	}

	public int getProductId() {
		return ProductId;
	}

	public void setProductId(int productId) {
		ProductId = productId;
	}

	public int getUserId() {
		return UserId;
	}

	public void setUserId(int userId) {
		UserId = userId;
	}

	public String getUserReview() {
		return UserReview;
	}

	public void setUserReview(String userReview) {
		UserReview = userReview;
	}

	public float getUserRating() {
		return UserRating;
	}

	public void setUserRating(float userRating) {
		UserRating = userRating;
	}

	public Feedback(int orderId, int productId, int userId, String userReview,
			float userRating) {
		super();
		OrderId = orderId;
		ProductId = productId;
		UserId = userId;
		UserReview = userReview;
		UserRating = userRating;
	}

	public Feedback() {
		super();
	}
	
	

}
