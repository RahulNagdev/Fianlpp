package com.cg.fb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.fb.dto.Feedback;
import com.cg.fb.service.FeedBackService;


@Controller

public class FeedBackController {
	@Autowired
FeedBackService feedbackservice;
	@RequestMapping(value="/home")
	public String getAllFeed(@ModelAttribute("my") Feedback fb ) {
		return "AddFeedBack";	 
	}
	
	@RequestMapping(value="adddata", method=RequestMethod.POST )
	public String addMobileData(@ModelAttribute("my") Feedback fb){
	
	feedbackservice.addFeedback(fb);
		return "Success";
	}

}
