package com.cg.bank.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.dao.ICustomerDAO;
import com.cg.bank.dto.Customer;
@Service("customerservice")
@Transactional

public class CustomerServiceImpl implements ICustomerService{
@Autowired
ICustomerDAO customerdao;

	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		customerdao.createAccount(customer);
	}

	@Override
	public void deposit(String mobileNo, Double amount) {
		// TODO Auto-generated method stub
		customerdao.deposit(mobileNo, amount);
	}

	@Override
	public void withdraw(String mobileNo, Double amount) {
		// TODO Auto-generated method stub
		customerdao.withdraw(mobileNo, amount);
	}

	@Override
	public Double checkBalance(String mobileNo) {
		// TODO Auto-generated method stub
		return customerdao.checkBalance(mobileNo);
	}

	@Override
	public void fundTransfer(String sender, String reciever, Double amount) {
		// TODO Auto-generated method stub
		
	}

}
