package com.cg.bank.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bank.dto.Customer;
import com.cg.bank.service.ICustomerService;

@Controller
public class CustomerController {
	@Autowired
	ICustomerService customerservice;
	@RequestMapping(value="/home")
	public String getAllCust(@ModelAttribute("my") Customer cust) {
	return "AddCustomer";	 
	}
	@RequestMapping(value="adddata",method=RequestMethod.POST )
	public String addMobileData(@Valid@ModelAttribute("my") Customer cust){
		customerservice.createAccount(cust);
		return "success";
	}

	@RequestMapping(value="deposit",method=RequestMethod.GET)
	public String deposit(@ModelAttribute("xy") Customer cust){
		return "deposit1";
		
	}
	@RequestMapping(value="deposit2",method=RequestMethod.POST)
	public String depo(@ModelAttribute("xy") Customer cust){
		customerservice.deposit(cust.getMobileNo(),cust.getInitialBalance());
		return "success2";
	}
	@RequestMapping(value="withdraw")
	public String withdraw(@ModelAttribute("xxy") Customer cust){
	return "withdraw1";
	
	}
	@RequestMapping(value="withdraw2",method=RequestMethod.POST)
	public String with(@ModelAttribute("xxy") Customer cust){
	customerservice.withdraw(cust.getMobileNo(),cust.getInitialBalance());
	return "success3";
	}
	@RequestMapping(value="balancecheck",method=RequestMethod.GET)
	public String checkbal(@ModelAttribute("yy") Customer cust){
		return "balancecheck";
	}
	@RequestMapping(value="checkbal",method=RequestMethod.POST)
	public ModelAndView dataSearch(@ModelAttribute("yy") Customer cust){
	Double balch=	customerservice.checkBalance(cust.getMobileNo());
	//System.out.println(mobsearch);
		return new ModelAndView("checkbal1","temp",balch);
	}
}