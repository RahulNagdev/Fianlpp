package com.cg.bank.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.bank.dto.Customer;
@Repository("customerdao")
public class CustomerDAOImpl implements ICustomerDAO{
	@PersistenceContext
	EntityManager em;
	
	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		em.persist(customer);
		em.flush();

	}

	@Override
	public void deposit(String mobileNo, Double amount) {
		// TODO Auto-generated method stub
		Customer cust = em.find(Customer.class, mobileNo);
		Double amt =cust.getInitialBalance();
		amt=amt+amount;
		cust.setInitialBalance(amt);
		em.flush();
	}

	@Override
	public void withdraw(String mobileNo, Double amount) {
		// TODO Auto-generated method stub
		Customer cust = em.find(Customer.class, mobileNo);
		Double amt =cust.getInitialBalance();
		amt=amt-amount;
		cust.setInitialBalance(amt);
		em.flush();
		}

	@Override
	public Double checkBalance(String mobileNo) {
		// TODO Auto-generated method stub
		Customer cust = em.find(Customer.class, mobileNo);
		Double amt =cust.getInitialBalance();
		return amt;
		
	}

	@Override
	public void fundTransfer(String sender, String reciever, Double amount) {
		// TODO Auto-generated method stub
		
	}

}
