package com.cg.bank.dto;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="customeracc")
public class Customer {
	
	@Column(name="cust_name")
	private String name;
	
	@Id
	@Column(name="mobile_no")
	private String mobileNo;
	@Column(name="age")
	private Float age;
	@Column(name="ini_bal")
	Double initialBalance;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		return "Customer [name=" + name + ", mobileNo=" + mobileNo + ", age="
				+ age + ", initialBalance=" + initialBalance + "]";
	}
	public Double getInitialBalance() {
		return initialBalance;
	}
	public void setInitialBalance(Double initialBalance) {
		this.initialBalance = initialBalance;
	}
	public Customer(String name, String mobileNo, float age, Double initialBalance) {
		this.name = name;
		this.mobileNo = mobileNo;
		this.age = age;
		this.initialBalance = initialBalance;
	}
	public Customer() {
		super();
	}

}
